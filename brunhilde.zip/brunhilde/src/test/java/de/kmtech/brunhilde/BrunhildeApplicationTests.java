package de.kmtech.brunhilde;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrunhildeApplicationTests {

	@Test
	void contextLoads() {
	}

}
